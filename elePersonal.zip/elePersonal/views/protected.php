<?php
/**
 * Created by PhpStorm.
 * User: JoelA
 * Date: 14/03/2018
 * Time: 01:55 AM
 */

include '../core/init.php';
?>

<h1>You need to be logged in to access this page</h1>
<p>Please log in</p>
