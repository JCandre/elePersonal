<!--
<footer class="footer">

    <div class="container">
        <p class="pull-right"><a href="#">Back to top</a></p>
        <p class="text-muted">&copy; 2016 Company, Inc. &middot; <a href="#">Privacy</a> &middot; <a href="#">Terms</a></p>
    </div>
</footer>
-->

<script src="js/moment.min.js"></script>
<script src="js/jquery.min.js"></script>
<script src="js/bootstrap.min.js"></script>
<script src="js/jquery-ui.min.js"></script>
<script src="js/fullcalendar.min.js"></script>



<script src="js/Core/passManager.js"></script>
<script src="js/Core/profManager.js"></script>
<script src="js/Core/regManager.js"></script>
<script src="js/Core/calManager.js"></script>
<script src="js/Core/main.js"></script>

