<head>
    <meta charset="UTF-8"/>
    <title> elePersonal</title>

    <link rel="stylesheet" type="text/css" href="css/fullcalendar.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/fullcalendar.print.min.css" media="print"/>
    <link rel="stylesheet" type="text/css" href="css/bootstrap.min.css"/>
    <link rel="stylesheet" type="text/css" href="css/jquery-ui.min.css"/>


    <link rel="stylesheet" type="text/css" href="css/core/regManager.css"/>
    <link rel="stylesheet" type="text/css" href="css/core/profManager.css"/>
    <link rel="stylesheet" type="text/css" href="css/core/logginManager.css"/>
    <link rel="stylesheet" type="text/css" href="css/core/Main.css"/>

    <!-- Website Font style -->
    <link rel="stylesheet" href="https://opensource.keycdn.com/fontawesome/4.6.3/font-awesome.min.css"
          integrity="sha384-Wrgq82RsEean5tP3NK3zWAemiNEXofJsTwTyHmNb/iL3dP/sZJ4+7sOld1uqYJtE" crossorigin="anonymous">

    <!-- Google Fonts -->
    <link href='https://fonts.googleapis.com/css?family=Passion+One' rel='stylesheet' type='text/css'>
    <link href='https://fonts.googleapis.com/css?family=Oxygen' rel='stylesheet' type='text/css'>

</head>