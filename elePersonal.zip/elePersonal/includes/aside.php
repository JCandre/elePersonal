<!--Left side column for navigation bar -->
<aside class="sidebar" id="toolsMenu" role="navigation">
    <div class="nav nav-sidebar toolsMenu_ul">
        <ul class="nav toolsMenu_ul" id="side-menu">
            <li><a href="Dashboard.php">Dashboard <span class="sr-only">(current)</span></a></li>
            <li><a href="Calendar.php">Calendar</a></li>
            <li><a href="addressBook.php">Address Book</a></li>
            <li><a href="Memos.php">Memos</a></li>
            <li><a href="Tasks.php">Task List</a></li>
            <li><a href="Mail.php">Mail</a></li>
        </ul>
        <ul class="nav toolsMenu_ul" id="side-menu">
            <!--<li><a href="testPage.php">Test page</a></li>-->
        </ul>

    </div>

</aside>