<html lang="en">

<?php
include 'includes/head.php';
?>

<body>
<?php include 'includes/header.php'; ?>
<div class="mycontainer mybody-content">